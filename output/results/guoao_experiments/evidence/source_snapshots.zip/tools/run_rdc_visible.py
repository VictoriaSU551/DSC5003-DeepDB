"""Bounded, visible RDC experiment. Original algorithm files remain unchanged."""
import os
os.environ.update(PYTHONHASHSEED='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='4', LOKY_MAX_CPU_COUNT='4', PYTHONUTF8='1')
import sys, json, pickle, hashlib, subprocess, time, threading, queue, traceback, runpy, re
from pathlib import Path
from datetime import datetime, timezone, timedelta
ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT/'DeepDB'
CODE = REPO/'code'
N = int(os.environ.get('DEEPDB_RDC_SAMPLES','100000'))
if N not in (100000,1000000): raise ValueError('Supported sample sizes: 100000, 1000000')
SEED = int(os.environ.get('DEEPDB_RDC_SEED','1'))
if SEED not in (1,2,3) or (SEED!=1 and N!=1000000):raise ValueError('Additional seeds require 1M samples')
OUT = REPO/('output/rdc_experiment_20261027' if N==100000 else 'output/rdc_experiment_20261027_1000000') if SEED==1 else REPO/('output/rdc_seed_experiments/seed_%d/samples_%d'%(SEED,N))
BASELINE_OUTPUT = REPO/'output' if SEED==1 else REPO/('output/seed_experiments/seed_%d/samples_%d'%(SEED,N))
PY = REPO/'.venv/Scripts/python.exe'
MODEL_NAME = 'ensemble_join_3_budget_5_%d.pkl'%N
SAMPLE_ZH = '10万' if N==100000 else '100万'
REPORT_NO = '12' if N==100000 else '14'
FIGURE_NO = '13' if N==100000 else '15'
def now(): return datetime.now(timezone(timedelta(hours=8))).isoformat()
def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    temp.replace(path)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def fix_paths(value, sampled=False):
    if isinstance(value,dict): return {k:fix_paths(v,sampled) for k,v in value.items()}
    if isinstance(value,list): return [fix_paths(v,sampled) for v in value]
    if isinstance(value,tuple): return tuple(fix_paths(v,sampled) for v in value)
    if isinstance(value,str) and value.endswith('.hdf'):
        name=value.replace('\\','/').split('/')[-1]
        return str((OUT/'hdf' if '_sampled.hdf' in name else REPO/'output/hdf')/name)
    return value
def worker(mode):
    sys.path.insert(0,str(CODE))
    import numpy as np, random
    stage_seed=SEED if mode=='train' else 1
    np.random.seed(stage_seed); random.seed(stage_seed)
    common=['--dataset','imdb-light','--csv_path',str(REPO/'data/imdb'),'--hdf_path',str(OUT/'hdf'),'--max_rows_per_hdf_file','100000000','--seed',str(stage_seed)]
    if mode=='prepare':
        if N==1000000:
            previous=REPO/'output/rdc_experiment_20261027/hdf'
            assert (previous/'meta_data_sampled.pkl').is_file()
            import shutil
            for p in previous.glob('*_sampled.hdf'):shutil.copy2(p,OUT/'hdf'/p.name)
            for filename in ['meta_data.pkl','meta_data_sampled.pkl']:
                (OUT/'hdf'/filename).write_bytes(pickle.dumps(fix_paths(pickle.loads((previous/filename).read_bytes())),pickle.HIGHEST_PROTOCOL))
            for table,info in pickle.loads((OUT/'hdf/meta_data_sampled.pkl').read_bytes()).items():
                assert Path(info['hdf_path']).is_file(),table
            dump(OUT/'sampling_reuse.json',dict(source=str(previous),scope='Identical 10K HDF pre-sample; full original HDF unchanged',files_sha256={p.name:sha(p) for p in (OUT/'hdf').glob('*_sampled.hdf')}))
            print('Reused and verified the same 10K HDF pre-sample; training samples differ only.',flush=True)
            return
        # Old author code gives the index the same name as a retained join-key column.
        # Removing only the index name resolves pandas ambiguity without changing rows.
        import inspect
        import data_preparation.join_data_preparation as jdp
        source=inspect.getsource(jdp.prepare_sample_hdf)
        for key in ['right_attribute','left_attribute']:
            old='df_samples = df_samples.set_index('+key+', drop=False)'
            source=source.replace(old,old+'\n                    df_samples.index.name = None')
        snapshot=OUT/'source/prepare_sample_hdf_compat.py'
        snapshot.parent.mkdir(exist_ok=True)
        snapshot.write_text(source,encoding='utf-8')
        exec(compile(source,str(snapshot),'exec'),jdp.__dict__)
        full=pickle.loads((REPO/'output/hdf/meta_data.pkl').read_bytes())
        fixed=fix_paths(full)
        (OUT/'hdf/meta_data.pkl').write_bytes(pickle.dumps(fixed,pickle.HIGHEST_PROTOCOL))
        args=['--generate_sampled_hdfs','--hdf_sample_size','10000']
    elif mode=='train':
        import ensemble_creation.rdc_based as rdc
        import psycopg2
        from joblight_exact_count import factorized_count_sql
        credentials=json.loads((ROOT/'tools/postgresql/local_credentials.json').read_text(encoding='utf-8-sig'))
        class LocalExactDB:
            def __init__(self,**ignored): pass
            def get_result(self,sql):
                # Author requests unfiltered inner-join COUNTs for the selected sub-schemas.
                # Add explicit aliases, then use the previously tested exact star aggregation.
                m=re.fullmatch(r'SELECT COUNT\(\*\) FROM (.+?) WHERE (.+)',sql,re.I)
                executed=sql
                if m:
                    aliased=', '.join(t.strip()+' '+t.strip() for t in m.group(1).split(','))
                    executed=factorized_count_sql('SELECT COUNT(*) FROM '+aliased+' WHERE '+m.group(2)+';')
                start=time.perf_counter()
                # Credential key names are selected locally; no secrets are logged.
                params={k:credentials[k] for k in ['host','port','user','password'] if k in credentials}
                params['host']=credentials.get('host','127.0.0.1')
                params['dbname']=credentials.get('database',credentials.get('dbname','deepdb_joblight'))
                conn=psycopg2.connect(**params,application_name='deepdb_rdc_training_counts')
                try:
                    conn.set_session(readonly=True,autocommit=True)
                    with conn.cursor() as cur:
                        cur.execute("SET statement_timeout='180s'")
                        cur.execute("SET work_mem='64MB'")
                        cur.execute("SET max_parallel_workers_per_gather=2")
                        cur.execute('SET jit=off')
                        cur.execute(executed); result=int(cur.fetchone()[0])
                finally: conn.close()
                with (OUT/'training_join_counts.jsonl').open('a',encoding='utf-8') as f:
                    f.write(json.dumps(dict(sql=sql,executed_sql=executed,count=result,seconds=time.perf_counter()-start,method='exact multiplicity aggregation' if m else 'original SQL'))+'\n')
                print('EXACT training join cardinality:',result,flush=True)
                return result
        rdc.DBConnection=LocalExactDB
        args=['--generate_ensemble','--ensemble_strategy','rdc_based','--samples_per_spn']+[str(N)]*5+['--samples_rdc_ensemble_tests','10000','--ensemble_path',str(OUT/'models'),'--database_name','deepdb_joblight','--post_sampling_factor','10','10','5','1','1','--ensemble_budget_factor','5','--ensemble_max_no_joins','3','--pairwise_rdc_path',str(OUT/'models/pairwise_rdc.pkl')]
    elif mode in ('evaluate_rdc','evaluate_greedy'):
        args=['--evaluate_cardinalities','--max_variants','1','--ensemble_location',str(OUT/'models'/MODEL_NAME),'--target_path',str(OUT/(mode+'.csv')),'--query_file_location',str(CODE/'benchmarks/job-light/sql/job_light_queries.sql'),'--ground_truth_file_location',str(CODE/'benchmarks/job-light/sql/job_light_true_cardinalities.csv')]
        if mode=='evaluate_rdc':args+=['--rdc_spn_selection','--pairwise_rdc_path',str(OUT/'models/pairwise_rdc.pkl')]
    elif mode=='verify':
        verify_and_report(); return
    else: raise ValueError(mode)
    sys.argv=[str(CODE/'maqp.py')]+common+args
    print('COMMAND',json.dumps(sys.argv,ensure_ascii=False),flush=True)
    runpy.run_path(str(CODE/'maqp.py'),run_name='__main__')
    if mode=='prepare':
        p=OUT/'hdf/meta_data_sampled.pkl'
        p.write_bytes(pickle.dumps(fix_paths(pickle.loads(p.read_bytes()),True),pickle.HIGHEST_PROTOCOL))
        for t,v in pickle.loads(p.read_bytes()).items():
            assert Path(v['hdf_path']).is_file(),(t,v['hdf_path'])
        print('Sampled metadata paths verified',flush=True)
def verify_and_report():
    import numpy as np, pandas as pd
    from ensemble_compilation.spn_ensemble import read_ensemble
    from evaluation.utils import parse_query
    from schemas.imdb.schema import gen_job_light_imdb_schema
    from rspn.algorithms.validity.validity import is_valid
    model=OUT/'models'/MODEL_NAME
    ensemble=read_ensemble(str(model),build_reverse_dict=True)
    schema=gen_job_light_imdb_schema(str(REPO/'data/imdb/{}.csv'))
    inventory=[]
    for spn in ensemble.spns:
        valid=is_valid(spn.mspn,check_ids=True)
        assert valid[0] if isinstance(valid,tuple) else valid
        inventory.append(dict(tables=sorted(spn.table_set),relationships=sorted(spn.relationship_set),actual_samples=int(spn.full_sample_size),full_join_size=float(spn.full_join_size)))
    assert set().union(*(s.table_set for s in ensemble.spns))==set(schema.table_dictionary)
    queries=(CODE/'benchmarks/job-light/sql/job_light_queries.sql').read_text().splitlines()
    truth=pd.read_csv(REPO/'output/truth_audit_20261027/truth_counts.csv')
    official=pd.read_csv(CODE/'benchmarks/job-light/sql/job_light_true_cardinalities.csv')
    frames={}; metrics={}; checks={}
    for name,path in [('relationship',BASELINE_OUTPUT/('results/job_light_%d.csv'%N)),('rdc_greedy',OUT/'evaluate_greedy.csv'),('rdc_selection',OUT/'evaluate_rdc.csv')]:
        f=pd.read_csv(path); frames[name]=f
        assert len(f)==70 and f.query_no.tolist()==list(range(70))
        assert f['query'].str.strip().tolist()==[q.strip() for q in queries]
        np.testing.assert_array_equal(f.cardinality_true,official.cardinality_true)
        np.testing.assert_array_equal(f.cardinality_true,truth.actual_count)
        assert np.isfinite(f[['cardinality_predict','cardinality_true','latency_ms']].values).all()
        assert (f.cardinality_predict>0).all()
        q=np.maximum(f.cardinality_predict/f.cardinality_true,f.cardinality_true/f.cardinality_predict)
        f['q_error']=q
        metrics[name]=dict(median=float(np.percentile(q,50)),p90=float(np.percentile(q,90)),p95=float(np.percentile(q,95)),max=float(q.max()),mean=float(q.mean()),mean_latency_ms=float(f.latency_ms.mean()))
        if name!='relationship':
            replay=[]
            for sql in queries:
                replay.append(ensemble.cardinality(parse_query(sql.strip(),schema),rdc_spn_selection=name=='rdc_selection',pairwise_rdc_path=str(OUT/'models/pairwise_rdc.pkl') if name=='rdc_selection' else None,max_variants=1,merge_indicator_exp=True,exploit_overlapping=True,return_factor_values=True)[2])
            np.testing.assert_allclose(replay,f.cardinality_predict,rtol=1e-9,atol=1e-7)
            checks[name]='70 saved-model predictions replayed and matched'
    base=frames['relationship']; r=frames['rdc_selection']
    paired=pd.DataFrame(dict(query_no=base.query_no,true_count=base.cardinality_true,baseline_estimate=base.cardinality_predict,rdc_estimate=r.cardinality_predict,baseline_q=base.q_error,rdc_q=r.q_error))
    paired['improvement_ratio']=paired.baseline_q/paired.rdc_q
    paired.to_csv(OUT/'paired_comparison.csv',index=False)
    wins=int((paired.rdc_q<paired.baseline_q).sum()); losses=int((paired.rdc_q>paired.baseline_q).sum())
    result=dict(status='PASS',requested_samples_per_spn=N,seed=SEED,queries=70,spns=len(inventory),inventory=inventory,metrics=metrics,rdc_wins=wins,rdc_losses=losses,ties=70-wins-losses,replay_checks=checks,model_sha256=sha(model),configuration=dict(budget_factor=5,max_joins=3,rdc_search_samples=10000,hdf_sample_size=10000,random_candidates=10000,learning_threshold=0.3,selection_threshold=0.15,training_and_search_seed=SEED,evaluation_seed=1,fixed_pre_sample_seed=1,python_hash_seed=1),limitations=['Per-run results require joint seed summary; scaled-down training, not paper-scale reproduction','Same requested samples per SPN, different number of SPNs; total sample and compute budget not equal','Baseline historical wall-clock training time is not a controlled runtime benchmark','No SQL execution speedup measured','All query truth values checked against independent audit (69 original SQL plus 1 equivalent exact count)'])
    dump(OUT/'verification.json',result)
    if SEED!=1:
        print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
        return
    run=json.loads((OUT/'run.json').read_text(encoding='utf-8'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.font_manager import FontProperties
    font=FontProperties(fname='C:/Windows/Fonts/msyh.ttc')
    for lang,folder in [('zh','中文版'),('en','英文版')]:
        target=ROOT/'学习记录/图表与解释'/folder;target.mkdir(parents=True,exist_ok=True)
        local=OUT/'reports'/lang;local.mkdir(parents=True,exist_ok=True)
        m=metrics
        if lang=='zh':
            text=f'RDC 优化模型对比（{SAMPLE_ZH}样本，种子1）\n\n我们做了什么：用已有 IMDb 数据，运行作者 RDC 模型集合选择，再预测同样70条查询的记录数。基础模型每个模型学习两张表；RDC 根据相关性选择组合，最多连接4张表。\n\n'
            text+='结果（q-error 越接近1越好）：\n'
            names=['基础模型','RDC集合＋普通选择','RDC集合＋RDC选择']
        else:
            text=f'RDC ensemble comparison ({N:,} requested samples per SPN, seed 1)\n\nWe ran the author RDC ensemble selection on the existing IMDb data and evaluated the same 70 JOB-light cardinality queries. Relationship models cover two tables; RDC can select joins of up to four tables.\n\nResults (q-error: closer to 1 is better):\n'
            names=['Relationship','RDC ensemble + greedy','RDC ensemble + RDC selection']
        for key,label in zip(metrics,names):text+=f'{label}: median={m[key]["median"]:.4f}, P95={m[key]["p95"]:.4f}, max={m[key]["max"]:.4f}\n'
        if lang=='zh':
            text+=f'\nRDC选择对基础模型：{wins}条改善、{losses}条变差、{70-wins-losses}条持平。模型数：基础5个，RDC {len(inventory)}个。\n'
            text+=f'\n设置：每模型请求{SAMPLE_ZH}样本；种子1；预算系数5；最多3条连接；RDC搜索与预采样1万；候选集合1万；学习阈值0.3，集合选择阈值0.15；推断max_variants=1。实际训练样本见模型清单。\n'
            text+='\n适配：不修改作者算法源文件；独立入口连接本机PostgreSQL。训练子模式的精确内连接大小通过已测试的等价分组计数计算；不使用70条测试查询的答案训练模型。目录迁移后只在实验副本修复HDF路径。预采样时清除重复的索引名称，消除Pandas索引与列同名歧义，保留索引值及数据行。兼容函数副本已保存。\n'
            text+='\n核验：所有RSPN结构有效；两种推断模式均从保存模型重载并逐条重算70个预测；结果与首次输出一致；真值与独立数据库核验一致（69条原SQL＋1条等价精确SQL）。\n'
            text+='\n限制：只有一个种子、训练样本低于论文规模；每模型样本数相同不代表总训练量相同；基础模型耗时是旧实验，不宜严格比速度；本实验没有证明SQL实际执行变快；不是完整论文复现，也不是从零重新实现算法。\n'
        else:
            text+=f'\nRDC selection versus relationship: {wins} improved, {losses} worsened, {70-wins-losses} tied; 5 baseline SPNs versus {len(inventory)} RDC SPNs.\n'
            text+='\nSettings: seed 1; budget factor 5; at most 3 joins; 10,000 RDC and HDF sampling rows; 10,000 candidate solutions; learning threshold 0.3, selection threshold 0.15; max_variants=1. Actual per-model samples are recorded in the inventory.\n'
            text+='\nAdaptation: the author algorithm source remains unchanged. A separate entry point connects to local PostgreSQL and uses the tested exact star-join aggregation for unfiltered training sub-schema sizes. No test-query answers are used for training. HDF path repairs are confined to experiment metadata copies. Pre-sampling clears duplicate index names to resolve pandas column/index ambiguity while retaining index values and data rows. The compatibility function is saved.\n'
            text+='\nValidation: all SPNs are structurally valid. Both inference modes reload the saved model and replay all 70 predictions. Truth matches the separate raw-data audit (69 original SQL successes plus one equivalent exact count).\n'
            text+='\nLimitations: one seed, smaller samples than the paper, unequal model counts and total training work. Historical baseline wall times are not a controlled speed benchmark. No actual SQL execution speedup is established. This is neither the full paper reproduction nor a from-scratch algorithm implementation.\n'
        text+='\nTraining subprocess seconds: '+str(round(run['stages']['train']['seconds'],2))+'\nModels:\n'+json.dumps(inventory,ensure_ascii=False,indent=2)+'\n'
        (target/(REPORT_NO+'_RDC优化模型对比报告.txt' if lang=='zh' else REPORT_NO+'_RDC_ensemble_comparison_report.txt')).write_text(text,encoding='utf-8')
        (local/'report.txt').write_text(text,encoding='utf-8')
        fig,ax=plt.subplots(figsize=(9,5));xs=np.arange(3);width=.32
        ax.bar(xs-width/2,[m[k]['median'] for k in m],width,label='Median')
        ax.bar(xs+width/2,[m[k]['p95'] for k in m],width,label='P95')
        ax.set_yscale('log');ax.set_ylabel('q-error (log scale; lower is better)');ax.set_xticks(xs)
        font_args={'fontproperties':font} if lang=='zh' else {}
        ax.set_xticklabels(names,fontsize=9,**font_args)
        ax.set_title(SAMPLE_ZH+'样本 RDC 对比（种子1）' if lang=='zh' else f'RDC comparison: {N:,} samples, seed 1',**font_args)
        ax.legend();fig.tight_layout()
        fig.savefig(str(target/(FIGURE_NO+'_RDC误差对比.png' if lang=='zh' else FIGURE_NO+'_RDC_q_error_comparison.png')),dpi=160)
        fig.savefig(str(local/'q_error_comparison.png'),dpi=160);plt.close(fig)
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
def gui():
    import tkinter as tk
    from tkinter.scrolledtext import ScrolledText
    OUT.mkdir(parents=True,exist_ok=True)
    for d in ['hdf','models','logs']: (OUT/d).mkdir(exist_ok=True)
    title='DeepDB RDC 优化模型对比 - '+SAMPLE_ZH+'样本'+(' - 种子%d'%SEED if SEED!=1 else '')
    ui=tk.Tk();ui.title(title);ui.geometry('1040x680')
    status=tk.StringVar(value='准备运行；每阶段自动保存进度。')
    tk.Label(ui,textvariable=status,font=('Microsoft YaHei UI',12),anchor='w').pack(fill='x',padx=12,pady=12)
    box=ScrolledText(ui,font=('Consolas',10),wrap='word');box.pack(fill='both',expand=True,padx=12,pady=6)
    events=queue.Queue();stop=threading.Event();active=[None]
    tk.Button(ui,text='保存并停止（保留已完成阶段）',command=stop.set).pack(pady=8)
    record_path=OUT/'run.json'
    record=json.loads(record_path.read_text(encoding='utf-8')) if record_path.exists() else dict(started_at=now(),stages={},samples=N,seed=SEED,scope='Vary global NumPy/Python seed for RDC search and training; fixed seed-1 HDF pre-sample, evaluation seed 1; author internal fixed seeds retained',source_sha256={str(p.relative_to(ROOT)):sha(p) for p in [Path(__file__).resolve(),CODE/'maqp.py',CODE/'ensemble_creation/rdc_based.py']})
    assert record['samples']==N and record['seed']==SEED
    def save():dump(record_path,record)
    def execute():
        started=time.perf_counter();record['status']='RUNNING';record.pop('error',None);save()
        try:
            for stage in ['prepare','train','evaluate_rdc','evaluate_greedy','verify']:
                if record['stages'].get(stage,{}).get('returncode')==0:
                    events.put(('log','REUSE completed stage: '+stage+'\n'));continue
                if stop.is_set():raise RuntimeError('Stopped by user before stage')
                events.put(('status','正在进行：'+stage+'；日志和结果自动保存在项目文件夹'))
                cmd=[str(PY),'-u',str(Path(__file__)), '--worker',stage]
                events.put(('log','\n========== '+stage+' ==========\n'))
                st=time.perf_counter()
                with (OUT/'logs'/(stage+'.log')).open('w',encoding='utf-8') as log:
                    proc=subprocess.Popen(cmd,cwd=OUT,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                    active[0]=proc;record['active_pid']=proc.pid;record['active_stage']=stage;save()
                    pos=0
                    while proc.poll() is None:
                        time.sleep(.5)
                        with (OUT/'logs'/(stage+'.log')).open(encoding='utf-8',errors='replace') as read:
                            read.seek(pos);chunk=read.read();pos=read.tell()
                        if chunk:events.put(('log',chunk))
                        if stop.is_set() or time.perf_counter()-started>2400:
                            proc.terminate();proc.wait(timeout=30)
                            raise RuntimeError('Stopped safely; completed stages retained (40 minute session limit)')
                    with (OUT/'logs'/(stage+'.log')).open(encoding='utf-8',errors='replace') as read:
                        read.seek(pos);chunk=read.read()
                    if chunk:events.put(('log',chunk))
                record['stages'][stage]=dict(returncode=proc.returncode,seconds=time.perf_counter()-st,finished_at=now(),command=cmd)
                save();active[0]=None
                if proc.returncode:raise RuntimeError('Stage failed: '+stage+'; logs retained')
            record['status']='PASS';events.put(('status','本轮完成：70条预测及两种推断方式的重载核验已保存。'))
        except BaseException as exc:
            record['status']='STOPPED_OR_FAILED';record['error']=str(exc)
            events.put(('status','已保存进度：'+str(exc)));events.put(('log',traceback.format_exc()))
        finally:
            record.pop('active_pid',None);record.pop('active_stage',None)
            record['last_session_seconds']=time.perf_counter()-started;record['updated_at']=now();save()
            note='RDC status: '+record['status']+'\nSamples: '+str(N)+'; seed: '+str(SEED)+'\nOutput: '+str(OUT)+'\nResume: set DEEPDB_RDC_SAMPLES='+str(N)+' and DEEPDB_RDC_SEED='+str(SEED)+' and run tools/run_rdc_visible.py with project Python. Completed stages are reused; failed stage restarts.\n'
            (ROOT/'学习记录/2026-10-27_RDC接续位置.txt').write_text(note,encoding='utf-8')
    def refresh():
        for _ in range(80):
            try:kind,value=events.get_nowait()
            except queue.Empty:break
            if kind=='status':status.set(value)
            else:box.insert('end',value);box.see('end')
        ui.after(500,refresh)
    def close():
        if active[0] and active[0].poll() is None:stop.set();status.set('正在保存并停止；结束后再关闭窗口。')
        else:ui.destroy()
    ui.protocol('WM_DELETE_WINDOW',close);ui.after(500,refresh)
    threading.Thread(target=execute,daemon=True).start();ui.mainloop()
if __name__=='__main__':
    if '--worker' in sys.argv:worker(sys.argv[-1])
    else:gui()
